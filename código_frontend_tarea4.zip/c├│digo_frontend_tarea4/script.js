 // Sistema de Login y Manejo de Datos 
 // Selección de elementos del DOM relacionados con el login
const modal = document.getElementById("loginModal");
const openBtn = document.getElementById("openLoginBtn");
const closeBtn = document.querySelector(".close-btn");
const loginForm = document.getElementById("loginForm");
const loginError = document.getElementById("loginError");


// Funciones para abrir/cerrar login
//Abre el modal de login y oculta posibles errores previos.
function openModal() {
    modal.style.display = "block";
    loginError.style.display = "none";
    loginError.textContent = "";
}
//Cierra el modal de login
function closeModal() {
    modal.style.display = "none";
}
// Asigna eventos a los botones de abrir y cerrar el modal
openBtn.addEventListener("click", openModal);
closeBtn.addEventListener("click", closeModal);
// Cierra el modal si el usuario hace clic fuera de él
window.addEventListener("click", (event) => {
    if (event.target === modal) {
        closeModal();
    }
});


//Asigna eventos de clic a cada botón y realiza solicitudes al servidor para obtener información de la categoría seleccionada.
//Cuando el usuario presiona un botón, se envía una solicitud al servidor para obtener datos.
document.querySelectorAll(".button").forEach(button => {
    button.addEventListener("click", function () {
        const tipo = this.classList[1];// Obtiene la categoría seleccionada (farmacias, médicos, citas, transportes)

        // Realiza la solicitud al servidor para obtener los datos de la categoría seleccionada.
        fetch("get_data.php?tipo=" + tipo)
            .then(response => response.json()) //Convierte la respuesta a JSON
            .then(data => {
                mostrarInformacion(tipo, data);// Muestra los datos recibidos.
                document.getElementById("info").style.display = "block";// Hace visible el contenedor de información
            })
            .catch(error => {
                console.error("Error al cargar datos:", error);
                document.getElementById("info").innerHTML = `<p style="color: red;">Error al cargar los datos.</p>`;
            });
    });
});

// Mostrar información
function mostrarInformacion(tipo, listado) {
    const contenedor = document.getElementById("info");
    // Establece un título dinámico según la categoría seleccionada
    contenedor.innerHTML = `<h2>${tipo.toUpperCase()}</h2>`;
// Itera sobre el listado de datos y los muestra en pantalla
    listado.forEach(item => {
        const itemDiv = document.createElement("div");
        // Filtra y excluye la clave "id" para evitar mostrar identificadores innecesarios
        itemDiv.innerHTML = Object.keys(item)
            .filter(key => key !== "id")
            .map(key => `<p><strong>${key}:</strong> ${item[key]}</p>`)
            .join("");
               // Agrega el contenido generado al contenedor principal
        contenedor.appendChild(itemDiv);
    });
}
